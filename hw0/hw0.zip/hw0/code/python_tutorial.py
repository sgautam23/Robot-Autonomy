#!/usr/bin/env python
import numpy as np

def print_list(l):
    print l

def sort_manual(shops):

    shops_sorted = []

    # TODO: Here implement manual sorting using loops

    print 'Manual sorting result: '
    print_list(shops_sorted)

def sort_python(shops):
    
    shops_sorted = []

    #TODO: Here implement sorting using python's built in sorting functions

    print 'Python sorting result: '
    print_list(shops_sorted)

def sort_numpy(shops):
    
    shops_sorted = []

    # TODO: Here implement sorting using numpy's built-in sorting function
    
    print 'Numpy sorting result: '
    print_list(shops_sorted)

def main():

    shops = {}
    shops['21st Street'] = 0.9
    shops['Voluto'] = 0.6
    shops['Coffee Tree'] = 0.45
    shops['Tazza D\' Oro'] = 0.75
    shops['Espresso a Mano'] = 0.95
    shops['Crazy Mocha'] = 0.35
    shops['Commonplace'] = 0.5

    sort_manual(shops)
    sort_python(shops)
    sort_numpy(shops)
    

if __name__ == "__main__":
    main()
